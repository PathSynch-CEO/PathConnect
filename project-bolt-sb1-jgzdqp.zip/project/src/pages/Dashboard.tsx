import React from 'react';
import { Users, Star, Coins, TrendingUp } from 'lucide-react';
import StatCard from '../components/StatCard';
import Chart from '../components/Chart';

export default function Dashboard() {
  return (
    <>
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Welcome back, Sarah</h1>
        <p className="text-gray-600 mt-1">Here's what's happening with your business today</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total Customers"
          value="2,847"
          change="+12.5%"
          isPositive={true}
          icon={Users}
        />
        <StatCard
          title="Review Score"
          value="4.8"
          change="+0.3"
          isPositive={true}
          icon={Star}
        />
        <StatCard
          title="Loyalty Points"
          value="156,242"
          change="+23.1%"
          isPositive={true}
          icon={Coins}
        />
        <StatCard
          title="Revenue"
          value="$24,389"
          change="-4.3%"
          isPositive={false}
          icon={TrendingUp}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Chart title="Customer Engagement" />
        <Chart title="Review Sentiment" />
      </div>
    </>
  );
}