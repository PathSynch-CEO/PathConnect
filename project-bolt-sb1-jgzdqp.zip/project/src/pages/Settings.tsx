import React, { useState } from 'react';
import { Building2, Link, Store } from 'lucide-react';

interface Location {
  id: string;
  name: string;
  address: string;
  phone: string;
  hours: string;
}

const initialLocations: Location[] = [
  {
    id: '1',
    name: 'Downtown Store',
    address: '123 Main St, City, ST 12345',
    phone: '(555) 123-4567',
    hours: 'Mon-Fri: 9AM-8PM, Sat-Sun: 10AM-6PM',
  },
  {
    id: '2',
    name: 'Westside Branch',
    address: '456 West Ave, City, ST 12345',
    phone: '(555) 987-6543',
    hours: 'Mon-Sat: 10AM-9PM, Sun: 11AM-6PM',
  },
];

const platforms = [
  { name: 'Shopify', status: 'Connected' },
  { name: 'WooCommerce', status: 'Not Connected' },
  { name: 'Square', status: 'Connected' },
  { name: 'Yelp', status: 'Not Connected' },
  { name: 'Google My Business', status: 'Connected' }
].map(platform => ({
  ...platform,
  description: `Connect your ${platform.name} account to sync reviews and customer data`,
  icon: platform.name === 'Google My Business' ? 'https://www.google.com/favicon.ico' : undefined
}));

export default function Settings() {
  const [activeSection, setActiveSection] = useState('locations');
  const [locations, setLocations] = useState(initialLocations);
  const [showAddLocation, setShowAddLocation] = useState(false);
  const [newLocation, setNewLocation] = useState<Partial<Location>>({});

  const handleAddLocation = (e: React.FormEvent) => {
    e.preventDefault();
    if (newLocation.name && newLocation.address) {
      setLocations([
        ...locations,
        {
          id: Date.now().toString(),
          name: newLocation.name,
          address: newLocation.address,
          phone: newLocation.phone || '',
          hours: newLocation.hours || '',
        },
      ]);
      setShowAddLocation(false);
      setNewLocation({});
    }
  };

  return (
    <div>
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600 mt-1">Manage your store settings and preferences</p>
      </header>

      <div className="bg-white rounded-xl shadow-sm">
        <div className="border-b">
          <nav className="flex">
            <button
              onClick={() => setActiveSection('locations')}
              className={`px-6 py-4 font-medium border-b-2 ${
                activeSection === 'locations'
                  ? 'border-[#336633] text-[#336633]'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <div className="flex items-center gap-2">
                <Store className="w-5 h-5" />
                Store Locations
              </div>
            </button>
            <button
              onClick={() => setActiveSection('integrations')}
              className={`px-6 py-4 font-medium border-b-2 ${
                activeSection === 'integrations'
                  ? 'border-[#336633] text-[#336633]'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <div className="flex items-center gap-2">
                <Link className="w-5 h-5" />
                Integrations
              </div>
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeSection === 'locations' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Store Locations</h2>
                <button
                  onClick={() => setShowAddLocation(true)}
                  className="bg-[#FFE816] text-[#336633] px-4 py-2 rounded-lg font-medium hover:bg-[#FFE816]/90"
                >
                  Add Location
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {locations.map((location) => (
                  <div key={location.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-[#336633]/10 rounded-lg">
                          <Building2 className="w-5 h-5 text-[#336633]" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{location.name}</h3>
                          <p className="text-sm text-gray-500">{location.address}</p>
                        </div>
                      </div>
                      <button className="text-gray-400 hover:text-gray-600">Edit</button>
                    </div>
                    <div className="mt-4 space-y-2 text-sm text-gray-600">
                      <p>Phone: {location.phone}</p>
                      <p>Hours: {location.hours}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeSection === 'integrations' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold">Connected Platforms</h2>
              <div className="space-y-4">
                {platforms.map((platform) => (
                  <div key={platform.name} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      {platform.icon && (
                        <img src={platform.icon} alt={platform.name} className="w-5 h-5" />
                      )}
                      <div>
                        <h3 className="font-medium">{platform.name}</h3>
                        <p className="text-sm text-gray-500">{platform.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span
                        className={`px-3 py-1 rounded-full text-sm ${
                          platform.status === 'Connected'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {platform.status}
                      </span>
                      <button
                        className={`px-4 py-1 rounded-lg text-sm font-medium ${
                          platform.status === 'Connected'
                            ? 'text-red-600 hover:bg-red-50'
                            : 'text-[#336633] hover:bg-[#336633]/10'
                        }`}
                      >
                        {platform.status === 'Connected' ? 'Disconnect' : 'Connect'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {showAddLocation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold mb-4">Add New Location</h2>
            <form onSubmit={handleAddLocation}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Location Name
                  </label>
                  <input
                    type="text"
                    value={newLocation.name || ''}
                    onChange={(e) => setNewLocation({ ...newLocation, name: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Address
                  </label>
                  <input
                    type="text"
                    value={newLocation.address || ''}
                    onChange={(e) => setNewLocation({ ...newLocation, address: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone
                  </label>
                  <input
                    type="text"
                    value={newLocation.phone || ''}
                    onChange={(e) => setNewLocation({ ...newLocation, phone: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Business Hours
                  </label>
                  <input
                    type="text"
                    value={newLocation.hours || ''}
                    onChange={(e) => setNewLocation({ ...newLocation, hours: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                  />
                </div>
                <div className="flex gap-2 mt-6">
                  <button
                    type="button"
                    onClick={() => setShowAddLocation(false)}
                    className="flex-1 px-4 py-2 border rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-[#FFE816] text-[#336633] px-4 py-2 rounded-lg font-medium hover:bg-[#FFE816]/90"
                  >
                    Add Location
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}