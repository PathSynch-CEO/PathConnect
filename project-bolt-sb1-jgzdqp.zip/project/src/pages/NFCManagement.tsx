import React, { useState } from 'react';
import { Plus, Search, Filter, Tag, MapPin, Megaphone } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface NFCCard {
  id: string;
  cardId: string;
  location: string;
  campaign: string;
  status: 'active' | 'inactive';
  lastUsed: string;
  interactions: number;
}

const initialCards: NFCCard[] = [
  {
    id: uuidv4(),
    cardId: 'NFC-001',
    location: 'Main Store',
    campaign: 'Summer Loyalty',
    status: 'active',
    lastUsed: '2024-03-10',
    interactions: 145,
  },
  {
    id: uuidv4(),
    cardId: 'NFC-002',
    location: 'Downtown Branch',
    campaign: 'New Customer Welcome',
    status: 'active',
    lastUsed: '2024-03-09',
    interactions: 89,
  },
];

export default function NFCManagement() {
  const [cards, setCards] = useState<NFCCard[]>(initialCards);
  const [showForm, setShowForm] = useState(false);
  const [newCard, setNewCard] = useState<Partial<NFCCard>>({
    cardId: '',
    location: '',
    campaign: '',
    status: 'active',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const card: NFCCard = {
      id: uuidv4(),
      cardId: newCard.cardId || '',
      location: newCard.location || '',
      campaign: newCard.campaign || '',
      status: 'active',
      lastUsed: '-',
      interactions: 0,
    };
    setCards([...cards, card]);
    setShowForm(false);
    setNewCard({ cardId: '', location: '', campaign: '', status: 'active' });
  };

  return (
    <div>
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">NFC Card Management</h1>
          <p className="text-gray-600 mt-1">Assign and track NFC cards across locations</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-[#FFE816] text-[#336633] px-4 py-2 rounded-lg font-medium hover:bg-[#FFE816]/90 flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Add NFC Card
        </button>
      </header>

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold mb-4">Add New NFC Card</h2>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Card ID
                  </label>
                  <input
                    type="text"
                    value={newCard.cardId}
                    onChange={(e) => setNewCard({ ...newCard, cardId: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Location
                  </label>
                  <input
                    type="text"
                    value={newCard.location}
                    onChange={(e) => setNewCard({ ...newCard, location: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Campaign
                  </label>
                  <input
                    type="text"
                    value={newCard.campaign}
                    onChange={(e) => setNewCard({ ...newCard, campaign: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                    required
                  />
                </div>
                <div className="flex gap-2 mt-6">
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="flex-1 px-4 py-2 border rounded-lg hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-[#FFE816] text-[#336633] px-4 py-2 rounded-lg font-medium hover:bg-[#FFE816]/90"
                  >
                    Add Card
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search cards..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#336633]"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-50">
            <Filter className="w-5 h-5" />
            Filters
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4">Card ID</th>
                <th className="text-left py-3 px-4">Location</th>
                <th className="text-left py-3 px-4">Campaign</th>
                <th className="text-left py-3 px-4">Status</th>
                <th className="text-left py-3 px-4">Last Used</th>
                <th className="text-left py-3 px-4">Interactions</th>
              </tr>
            </thead>
            <tbody>
              {cards.map((card) => (
                <tr key={card.id} className="border-b hover:bg-gray-50">
                  <td className="py-3 px-4 flex items-center gap-2">
                    <Tag className="w-4 h-4 text-[#336633]" />
                    {card.cardId}
                  </td>
                  <td className="py-3 px-4 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-gray-400" />
                    {card.location}
                  </td>
                  <td className="py-3 px-4 flex items-center gap-2">
                    <Megaphone className="w-4 h-4 text-gray-400" />
                    {card.campaign}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                        ${
                          card.status === 'active'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                    >
                      {card.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">{card.lastUsed}</td>
                  <td className="py-3 px-4">{card.interactions}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}