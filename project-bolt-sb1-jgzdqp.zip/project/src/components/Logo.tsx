import React from 'react';
import { BarChart3 } from 'lucide-react';

export default function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="relative">
        <div className="absolute inset-0 bg-white/20 blur-sm rounded-lg"></div>
        <BarChart3 className="w-8 h-8 relative text-white" />
      </div>
      <div>
        <h1 className="text-xl font-bold text-white">PathManager</h1>
        <p className="text-xs text-indigo-200">Analytics Dashboard</p>
      </div>
    </div>
  );
}